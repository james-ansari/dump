jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/sap/hcl/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/sap/hcl/test/integration/pages/App",
	"com/sap/hcl/test/integration/pages/Browser",
	"com/sap/hcl/test/integration/pages/Master",
	"com/sap/hcl/test/integration/pages/Detail",
	"com/sap/hcl/test/integration/pages/NotFound"
], function(Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.sap.hcl.view."
	});

	sap.ui.require([
		"com/sap/hcl/test/integration/NavigationJourneyPhone",
		"com/sap/hcl/test/integration/NotFoundJourneyPhone",
		"com/sap/hcl/test/integration/BusyJourneyPhone"
	], function() {
		QUnit.start();
	});
});