jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 Users in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/sap/hcl/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/sap/hcl/test/integration/pages/App",
	"com/sap/hcl/test/integration/pages/Browser",
	"com/sap/hcl/test/integration/pages/Master",
	"com/sap/hcl/test/integration/pages/Detail",
	"com/sap/hcl/test/integration/pages/Create",
	"com/sap/hcl/test/integration/pages/NotFound"
], function(Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.sap.hcl.view."
	});

	sap.ui.require([
		"com/sap/hcl/test/integration/MasterJourney",
		"com/sap/hcl/test/integration/NavigationJourney",
		"com/sap/hcl/test/integration/NotFoundJourney",
		"com/sap/hcl/test/integration/BusyJourney",
		"com/sap/hcl/test/integration/FLPIntegrationJourney"
	], function() {
		QUnit.start();
	});
});